namespace WowPacketParser.Enums
{
    public enum QuestType
    {
        AutoComplete      = 0,
        Unknown           = 1,
        Normal            = 2,
        BonusOrWorldQuest = 3
    }
}
