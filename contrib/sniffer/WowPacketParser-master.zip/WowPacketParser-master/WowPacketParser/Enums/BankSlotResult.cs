﻿namespace WowPacketParser.Enums
{
    public enum  BankSlotResult
    {
        TooMany        = 0,
        NotEnoughMoney = 1,
        NotBanker      = 2,
        Ok             = 3
    }
}
