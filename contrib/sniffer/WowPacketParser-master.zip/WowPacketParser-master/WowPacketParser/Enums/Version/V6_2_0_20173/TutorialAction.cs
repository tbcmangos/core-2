﻿namespace WowPacketParser.Enums.Version.V6_2_0_20173
{
    public enum TutorialAction
    {
        Reset   = 1,
        Clear   = 2,
        Update  = 3,
    }
}
