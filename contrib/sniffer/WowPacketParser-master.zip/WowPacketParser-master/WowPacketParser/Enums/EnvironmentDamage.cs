namespace WowPacketParser.Enums
{
    public enum EnvironmentDamage
    {
        Exhausted = 0,
        Drowing   = 1,
        Fall      = 2,
        Lava      = 3,
        Slime     = 4,
        Fire      = 5
    }
}
