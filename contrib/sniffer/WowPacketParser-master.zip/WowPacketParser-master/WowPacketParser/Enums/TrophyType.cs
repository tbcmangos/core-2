﻿namespace WowPacketParser.Enums
{
    public enum TrophyType
    {
        Horde    = 3,
        Alliance = 4,
    }
}
