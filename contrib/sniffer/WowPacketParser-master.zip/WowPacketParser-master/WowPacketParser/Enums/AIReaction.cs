namespace WowPacketParser.Enums
{
    public enum AIReaction
    {
        Alert    = 0,
        Friendly = 1,
        Hostile  = 2,
        Afraid   = 3,
        Destroy  = 4
    }
}
