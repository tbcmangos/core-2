namespace WowPacketParser.Enums
{
    public enum LootRollType
    {
        Pass       = 0,
        Need       = 1,
        Greed      = 2,
        Disenchant = 3
    }
}
