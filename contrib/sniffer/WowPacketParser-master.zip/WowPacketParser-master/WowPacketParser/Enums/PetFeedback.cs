namespace WowPacketParser.Enums
{
    public enum PetFeedback
    {
        None             = 0,
        PetDead          = 1,
        NothingToAttack  = 2,
        CantAttackTarget = 3,
        ChargeHasNoPath  = 4
    }
}
