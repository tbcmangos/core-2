﻿namespace WowPacketParser.Enums
{
    public enum CalendarEventType
    {
        Raid    = 0,
        Dungeon = 1,
        PVP     = 2,
        Meeting = 3,
        Other   = 4,
        Heroic  = 5
    }
}
