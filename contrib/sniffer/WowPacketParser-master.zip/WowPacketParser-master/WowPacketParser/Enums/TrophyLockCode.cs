﻿namespace WowPacketParser.Enums
{
    public enum TrophyLockCode
    {
        WrongAchievement = 34,
        Success          = 57,
    }
}
