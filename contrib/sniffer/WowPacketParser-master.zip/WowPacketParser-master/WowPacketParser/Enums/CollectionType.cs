﻿namespace WowPacketParser.Enums
{
    public enum CollectionType : int
    {
        None            = -1,
        ToyBox          = 1,
        Appearance      = 3,
        TransmogSet     = 4
    };
}
