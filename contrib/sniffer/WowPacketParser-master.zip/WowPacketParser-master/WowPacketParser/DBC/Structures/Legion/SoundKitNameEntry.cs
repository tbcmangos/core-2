﻿namespace WowPacketParser.DBC.Structures.Legion
{
    [DBFile("SoundKitName")]
    public sealed class SoundKitNameEntry
    {
        public string Name;
    }
}
