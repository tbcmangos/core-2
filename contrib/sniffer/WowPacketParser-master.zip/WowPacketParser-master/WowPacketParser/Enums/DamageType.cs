namespace WowPacketParser.Enums
{
    public enum DamageType : byte
    {
        Physical = 0,
        Holy     = 1,
        Fire     = 2,
        Nature   = 3,
        Frost    = 4,
        Shadow   = 5,
        Arcane   = 6
    }
}
