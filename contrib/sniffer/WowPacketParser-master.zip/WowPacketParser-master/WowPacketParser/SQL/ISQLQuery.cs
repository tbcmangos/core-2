﻿namespace WowPacketParser.SQL
{
    interface ISQLQuery
    {
        string Build();
    }
}
