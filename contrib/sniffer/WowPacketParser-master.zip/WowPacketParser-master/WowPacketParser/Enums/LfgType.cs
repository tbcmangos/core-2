namespace WowPacketParser.Enums
{
    public enum LfgType
    {
        None    = 0,
        Dungeon = 1,
        Raid    = 2,
        Quest   = 3,
        Zone    = 4,
        Heroic  = 5,
        Random  = 6
    }
}
