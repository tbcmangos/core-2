namespace WowPacketParser.Enums
{
    public enum BarberShopResult
    {
        Success  = 0,
        NoMoney1 = 1,
        MustSit  = 2,
        NoMoney2 = 3
    }
}
