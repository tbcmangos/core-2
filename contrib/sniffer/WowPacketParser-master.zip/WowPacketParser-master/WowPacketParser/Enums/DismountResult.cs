namespace WowPacketParser.Enums
{
    public enum DismountResult
    {
        NoPet      = 0,
        NotMounted = 1,
        NotYourPet = 2,
        Ok         = 3 // ?
    }
}
