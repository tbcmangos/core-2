namespace WowPacketParser.Enums
{
    public enum PetitionResultType
    {
        Ok                 = 0,
        AlreadySigned      = 1,
        AlreadyInGuild     = 2,
        CantSignOwn        = 3,
        NeedMoreSignatures = 4,
        Unk5               = 5
    }
}
