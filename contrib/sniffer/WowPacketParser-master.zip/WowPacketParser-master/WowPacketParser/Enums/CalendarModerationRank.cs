﻿namespace WowPacketParser.Enums
{
    public enum CalendarModerationRank
    {
        Player    = 0,
        Moderator = 1,
        Owner     = 2
    }
}
