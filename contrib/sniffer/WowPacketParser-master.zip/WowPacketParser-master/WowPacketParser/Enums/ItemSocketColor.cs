namespace WowPacketParser.Enums
{
    public enum ItemSocketColor : byte
    {
        None   = 0,
        Meta   = 1,
        Red    = 2,
        Yellow = 4,
        Blue   = 8
    }
}
