namespace WowPacketParser.Enums
{
    public enum PageMaterial
    {
        None      = 0,
        Parchment = 1,
        Stone     = 2,
        Marble    = 3,
        Silver    = 4,
        Bronze    = 5,
        Valentive = 6,
        Illidan   = 7
    }
}
