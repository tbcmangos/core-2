namespace WowPacketParser.Enums
{
    public enum TeamType
    {
        None               = 0,
        Horde              = 67,
        SteamwheedleCartel = 169,
        Alliance           = 469,
        AllianceForces     = 891,
        HordeForces        = 892,
        Sanctuary          = 936,
        Outland            = 980
    }
}
