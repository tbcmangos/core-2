namespace WowPacketParser.Enums
{
    public enum ItemBonding
    {
        None         = 0,
        WhenPickedUp = 1,
        WhenEquipped = 2,
        WhenUsed     = 3,
        QuestItem    = 4
    }
}
