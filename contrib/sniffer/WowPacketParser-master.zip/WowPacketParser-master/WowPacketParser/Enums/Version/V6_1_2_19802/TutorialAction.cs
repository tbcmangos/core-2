﻿namespace WowPacketParser.Enums.Version.V6_1_2_19802
{
    public enum TutorialAction
    {
        Reset   = 0,
        Update  = 1,
        Clear   = 2
    }
}
