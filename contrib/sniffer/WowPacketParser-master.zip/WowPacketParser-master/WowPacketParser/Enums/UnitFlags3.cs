﻿using System;

namespace WowPacketParser.Enums
{
    [Flags]
    public enum UnitFlags3
    {
        None                    = 0x0,
        Unk1                    = 0x1,
    }
}
