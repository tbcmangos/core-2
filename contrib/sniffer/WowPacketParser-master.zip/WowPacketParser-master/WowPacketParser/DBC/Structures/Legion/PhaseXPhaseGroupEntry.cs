﻿namespace WowPacketParser.DBC.Structures.Legion
{
    [DBFile("PhaseXPhaseGroup")]

    public sealed class PhaseXPhaseGroupEntry
    {
        public ushort PhaseID;
        public ushort PhaseGroupID;
    }
}
