namespace WowPacketParser.Enums
{
    public enum DrunkenState
    {
        Sober   = 0,
        Tipsy   = 1,
        Drunk   = 2,
        Smashed = 3
    }
}
