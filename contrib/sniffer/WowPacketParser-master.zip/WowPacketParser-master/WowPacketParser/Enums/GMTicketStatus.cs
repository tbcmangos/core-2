namespace WowPacketParser.Enums
{
    public enum GMTicketStatus
    {
        HasText = 6,
        NoText  = 10
    }
}
