namespace WowPacketParser.Enums
{
    public enum ReputationRank
    {
        Hated      = 0,
        Hostile    = 1,
        Unfriendly = 2,
        Neutral    = 3,
        Friendly   = 4,
        Honored    = 5,
        Revered    = 6,
        Exalted    = 7
    }
}
