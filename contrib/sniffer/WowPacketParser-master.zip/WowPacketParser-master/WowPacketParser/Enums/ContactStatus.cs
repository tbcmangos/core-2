namespace WowPacketParser.Enums
{
    public enum ContactStatus
    {
        Offline = 0,
        Online  = 1,
        Afk     = 2,
        Unknown = 4,
        Dnd     = 5
    }
}
