﻿namespace WowPacketParser.Enums
{
    public enum CalendarRepeatType
    {
        Never    = 0,
        Weekly   = 1,
        BiWeekly = 2,
        Monthly  = 3
    }
}
