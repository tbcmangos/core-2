﻿namespace WowPacketParser.Enums
{
    public enum AttackSwingErr
    {
        CantAttack = 0,
        NotInRange = 1,
        BadFacing = 2,
        DeadTarget = 3
    }
}
