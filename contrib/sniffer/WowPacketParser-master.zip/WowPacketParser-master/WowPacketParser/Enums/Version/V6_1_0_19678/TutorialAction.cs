﻿namespace WowPacketParser.Enums.Version.V6_1_0_19678
{
    public enum TutorialAction
    {
        Clear   = 1,
        Update  = 2,
        Reset   = 3,
    }
}
