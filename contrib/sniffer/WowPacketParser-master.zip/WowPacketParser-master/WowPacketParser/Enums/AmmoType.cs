namespace WowPacketParser.Enums
{
    public enum AmmoType : byte
    {
        None    = 0,
        Arrows  = 2,
        Bullets = 3,
        Thrown  = 4
    }
}
