namespace WowPacketParser.Enums
{
    public enum TrainerType
    {
        Class       = 0,
        Mounts      = 1,
        Tradeskills = 2,
        Pets        = 3
    }
}
