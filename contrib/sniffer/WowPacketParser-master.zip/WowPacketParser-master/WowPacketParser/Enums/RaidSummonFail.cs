﻿namespace WowPacketParser.Enums
{
    enum RaidSummonFail
    {
        None          = 0,
        RealmMismatch = 1,
        RaidLocked    = 2,
        MapCondition  = 3,
        DeathOrGhost  = 4,
        Offline       = 5
    }
}
