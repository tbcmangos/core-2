﻿namespace WowPacketParser.Enums
{
    public enum GarrisonMissionResult
    {
        Success,
        Failure
    }
}
