﻿namespace WowPacketParser.Enums
{
    public enum GarrisonSite
    {
        None              = 0,
        Lunarfall         = 2,
        Frostwall         = 71,
        AllianceClassHall = 161,
        HordeClassHall    = 163,
        AllianceBfA       = 168,
        HordeBfA          = 169
    }
}
