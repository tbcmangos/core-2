namespace WowPacketParser.Enums
{
    public enum StatType
    {
        Strength  = 0,
        Agility   = 1,
        Stamina   = 2,
        Intellect = 3,
        Spirit    = 4
    }
}
