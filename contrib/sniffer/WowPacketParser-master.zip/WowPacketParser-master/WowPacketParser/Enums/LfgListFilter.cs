﻿namespace WowPacketParser.Enums
{
    public enum LfgListFilter
    {
        Recommended      = 1,
        NotRecommended   = 2,
        PvE              = 4,
        PvP              = 8,
    }
}
