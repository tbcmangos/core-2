namespace WowPacketParser.Enums
{
    public enum TwitterResult
    {
        Success   = 0,
        NotLinked = 1,
        Fail      = 2
    }
}
