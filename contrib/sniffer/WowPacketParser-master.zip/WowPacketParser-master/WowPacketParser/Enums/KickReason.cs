namespace WowPacketParser.Enums
{
    public enum KickReason
    {
        NoGenericReason  = 0,
        DuplicateSession = 1,
        NoGameTime       = 2,
        AccountBanned    = 3,
        ParentalControl  = 4
    }
}
