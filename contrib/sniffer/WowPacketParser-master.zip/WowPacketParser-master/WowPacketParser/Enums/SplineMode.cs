namespace WowPacketParser.Enums
{
    public enum SplineMode
    {
        Linear     = 0,
        CatmullRom = 1,
        Smooth     = 2 // 4.x
    }
}
