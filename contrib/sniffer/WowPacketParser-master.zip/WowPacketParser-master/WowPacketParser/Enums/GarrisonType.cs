﻿namespace WowPacketParser.Enums
{
    public enum GarrisonType : int
    {
        None            = 0,
        DraenorGarrison = 2,
        OrderHall       = 3,
        BfA             = 9
    }
}
