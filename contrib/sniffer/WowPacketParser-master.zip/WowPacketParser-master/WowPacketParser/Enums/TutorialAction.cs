﻿namespace WowPacketParser.Enums
{
    public enum TutorialAction
    {
        Update = 0,
        Clear  = 1,
        Reset  = 2
    }
}
