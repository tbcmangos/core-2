namespace WowPacketParser.Enums
{
    public enum MailType
    {
        Normal     = 0,
        Auction    = 2,
        Creature   = 3,
        GameObject = 4,
        Item       = 5
    }
}
