namespace WowPacketParser.Enums
{
    public enum LootSlotType
    {
        AllowLoot   = 0,
        RollOngoing = 1,
        Master      = 2,
        Locked      = 3,
        Owner       = 4
    }
}
