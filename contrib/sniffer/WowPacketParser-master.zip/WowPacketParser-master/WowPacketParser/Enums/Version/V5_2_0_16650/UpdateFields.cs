namespace WowPacketParser.Enums.Version.V5_2_0_16650
{
    // TODO: fix update fields for this version.
}
