﻿namespace WowPacketParser.Enums
{
    public enum TargetIcon
    {
        None              = -1,
        Yellow4PointStar  = 0,
        OrangeCircle      = 1,
        PurpleDiamond     = 2,
        GreenTriangle     = 3,
        WhiteCrescentMoon = 4,
        BlueSquare        = 5,
        RedCross          = 6,
        WhiteSkull        = 7
    }
}
