﻿namespace WowPacketParser.Enums
{
    public enum SniffType
    {
        Bin,
        Pkt,
        Sqlite
    }
}
