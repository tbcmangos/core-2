namespace WowPacketParser.Enums
{
    public enum GMTicketResponse
    {
        Failure = 1,
        Success = 2,
        Deleted = 9
    }
}
