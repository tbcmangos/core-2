namespace WowPacketParser.Enums
{
    public enum Class
    {
        None        = 0,
        Warrior     = 1,
        Paladin     = 2,
        Hunter      = 3,
        Rogue       = 4,
        Priest      = 5,
        DeathKnight = 6,
        Shaman      = 7,
        Mage        = 8,
        Warlock     = 9,
        Monk        = 10,
        Druid       = 11,
        DemonHunter = 12
    }
}
