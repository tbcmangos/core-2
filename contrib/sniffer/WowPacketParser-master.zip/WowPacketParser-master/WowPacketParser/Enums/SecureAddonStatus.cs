﻿namespace WowPacketParser.Enums
{
    public enum SecureAddonStatus : byte
    {
        Banned = 0,
        SecureVisible = 1,
        SecureHidden = 2
    }
}
