﻿namespace WowPacketParser.Enums
{
    public enum GarrisonFollowerQuality
    {
        None,
        Common,
        Uncommon,
        Rare,
        Epic,
        Legendary,
        Title
    }
}
