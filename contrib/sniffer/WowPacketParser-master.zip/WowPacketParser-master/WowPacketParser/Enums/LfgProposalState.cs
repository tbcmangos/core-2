namespace WowPacketParser.Enums
{
    public enum LfgProposalState
    {
        Initiating = 0,
        Failed     = 1,
        Success    = 2
    }
}
