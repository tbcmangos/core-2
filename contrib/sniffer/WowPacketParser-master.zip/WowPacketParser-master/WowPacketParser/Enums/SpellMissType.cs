namespace WowPacketParser.Enums
{
    public enum SpellMissType
    {
        None    = 0,
        Miss    = 1,
        Resist  = 2,
        Dodge   = 3,
        Parry   = 4,
        Block   = 5,
        Evade   = 6,
        Immune1 = 7,
        Immune2 = 8,
        Deflect = 9,
        Absorb  = 10,
        Reflect = 11
    }
}
