namespace WowPacketParser.Enums
{
    public enum MirrorTimerType
    {
        Fatigue    = 0,
        Breath     = 1,
        FeignDeath = 2,
        Unknown    = 3
    }
}
