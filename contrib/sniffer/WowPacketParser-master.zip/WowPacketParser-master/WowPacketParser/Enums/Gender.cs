namespace WowPacketParser.Enums
{
    public enum Gender
    {
        Male   = 0,
        Female = 1,
        None   = 2
    }
}
