﻿namespace WowPacketParser.Enums
{
    public enum GuildNewsType
    {
        GuildAchievement  = 0,
        PlayerAchievement = 1,
        RaidEncounters    = 2,
        ItemLooted        = 3,
        ItemCrafted       = 4,
        ItemPurchased     = 5,
        GuildLevel        = 6
    }
}
