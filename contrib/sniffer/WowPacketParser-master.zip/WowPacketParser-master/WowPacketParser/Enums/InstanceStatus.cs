namespace WowPacketParser.Enums
{
    public enum InstanceStatus
    {
        NotSaved  = 0,
        Saved     = 1,
        Completed = 2
    }
}
