namespace WowPacketParser.Enums
{
    public enum MapDifficulty
    {
        NormalOrNormal10Man     = 0,
        HeroicOrNormal25Man     = 1,
        EpicOrHeroic10Man       = 2,
        EpicHeroicOrHeroic25Man = 3
    }
}
