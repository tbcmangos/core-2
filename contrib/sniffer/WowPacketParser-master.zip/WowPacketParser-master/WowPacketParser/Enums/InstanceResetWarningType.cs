namespace WowPacketParser.Enums
{
    public enum InstanceResetWarningType
    {
        None        = 0,
        Hours       = 1,
        Minutes     = 2,
        MinutesSoon = 3,
        Welcome     = 4,
        Expired     = 5
    }
}
