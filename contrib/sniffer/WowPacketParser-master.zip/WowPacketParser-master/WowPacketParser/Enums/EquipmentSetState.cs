namespace WowPacketParser.Enums
{
    public enum EquipmentSetState
    {
        Unchanged = 0,
        Changed   = 1,
        New       = 2,
        Deleted   = 3
    }
}
