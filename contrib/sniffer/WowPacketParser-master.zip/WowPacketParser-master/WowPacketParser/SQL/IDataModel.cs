﻿namespace WowPacketParser.SQL
{
    /// <summary>
    /// Interface which has to be implemented by every data model.
    /// </summary>
    public interface IDataModel
    {
    }
}
