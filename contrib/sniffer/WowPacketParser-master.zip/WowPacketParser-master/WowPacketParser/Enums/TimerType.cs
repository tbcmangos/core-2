﻿namespace WowPacketParser.Enums
{
    public enum TimerType : uint
    {
        Pvp            = 0,
        ChallengerMode = 1
    }
}
